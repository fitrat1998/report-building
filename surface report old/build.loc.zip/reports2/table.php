<?php
session_start();
include "../config.php";

$ide = $_POST["ide"];


$sql = mysqli_query(
    $link,
    "SELECT object_id, section, floor,IF(status='Finished', 'Finished', 'In proccess'), created_date, updated_date, COUNT(section), SUM(surface) FROM extra_object WHERE section='$ide' GROUP BY section HAVING COUNT(section) > 0;"
);


$res = array();
$res2 = array();
$sum = 0;


while ($row = mysqli_fetch_assoc($sql)) {

   $section = $row['section'];
   $status = $row['status'];
   $obj_id = $row['object_id'];


    $id = $row['object_id'];
    $sql2 = mysqli_query($link,"SELECT * FROM objects WHERE id = '$obj_id'");
    $res2 = mysqli_fetch_assoc($sql2);

    $sql3 = mysqli_query($link,"SELECT * FROM extra_object WHERE section = '$section' AND status='Finished'");
    $res3 = mysqli_fetch_assoc($sql3);


    $sql4 = mysqli_query($link,"SELECT * FROM sections WHERE section_name = '$section'");
    $res4 = mysqli_fetch_assoc($sql4);    

    if($row['updated_date'] == ""){
       $up = 0;
    }
    else{
       $up = date("Y-m-d",$row['updated_date']);

    }

    $cr = date("Y-m-d",$row['created_date']);

    array_push(
      $res, 
      [ 

         $res2["obj_name"],
         $row["floor"],
         $res4["section_name"],
         $row['SUM(surface)'],
         $cr,
         $up,
         $res3 ? "Finished" : "In proccess",
      ]
);
}



echo json_encode($res);
?>
   
