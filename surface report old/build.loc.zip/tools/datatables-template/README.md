# DataTables Template

A Pen created on CodePen.io. Original URL: [https://codepen.io/RedJokingInn/pen/bwgMwB](https://codepen.io/RedJokingInn/pen/bwgMwB).

Just a simple datatables initial setup as example and for future use to build more advanced examples.