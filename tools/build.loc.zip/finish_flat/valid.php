<?php 
	include '../config.php';


	 $ret = [];

     if ($_POST['object_id'] == "Choose object") {
	 	$ret += ['xatolik'=>1,'xabar'=>'Choose object please!!!'];
	 }
	 else{
	 	 $id = trim($_POST['object_id']);
	 }


	 if ($_POST['section'] != "Choose section") {
	 	$section = trim($_POST['section']);
	 }
	 else{
	 	$ret += ['xatolik'=>1,'xabar'=>'Choose section please!!!'];
	 }

	 if ($_POST['floor'] == "Choose floor") {
	 	$ret += ['xatolik'=>1,'xabar'=>'Choose floor please!!!'];
	 }
	 else{
	 	$floor = trim($_POST['floor']);
	 }

	 if ($_POST['room'] == "Choose flat") {
	 	$ret += ['xatolik'=>1,'xabar'=>'Choose room please!!!'];
	 }
	 else{
	 	$flat = trim($_POST['room']);
	 }

	 $surface = trim($_POST['surface']);

	 if(empty($_POST['worker'])){
	 	$ret += ['xatolik'=>1,'xabar'=>'Choose workers please!!!'];
	 }
	 else {
	 	$workers = $_POST['worker'];
	 }

	 if($_POST['status']== "true") {
	 	$status = "Finished";
	 }
	 else {
	 	$status = "In proccess";
	 }

	 $time = time();

	 $master = "";

	foreach($workers as $worker){
		$master .= $worker.", ";
	}

	$old = mysqli_query($link,"SELECT * FROM extra_object WHERE object_id = '$id' AND section = '$section' AND floor = '$floor' AND flat = '$flat' ORDER BY created_date DESC");
	$res = mysqli_fetch_assoc($old);

	if($res['status'] == "Finished"){
		$ret += ['xatolik'=>1,'xabar'=>'The object already exists on the table!!!'];
		echo json_encode($ret);
		die();
	}
	else {
		$sql = mysqli_query($link,"INSERT INTO extra_object(object_id,floor,flat,section,surface,workers,created_date,updated_date,status)
		 	   VALUES('$id','$floor','$flat','$section','$surface','$master','$time','','$status')");

		 if($sql){
		 	$ret += ['xatolik'=>0, 'xabar'=>'Section added successfully!!!'];
		 }
		 else {
		 	$ret += ['xatolik'=>1,'xabar'=>'Something went wrong!!!'];
		 }

		 if ($status == "Finished") {
		 	 $update = mysqli_query($link,"UPDATE extra_object SET status = '$status' WHERE object_id = '$id' AND 
		 	 	section = '$section' AND status = 'In proccess'");
		 }
	}

	 echo json_encode($ret);
?>