	<?php 
	session_start();
	include '../config.php';

	$ret = [];

	if(!empty($_POST['project_id'])){
		$project_id = trim($_POST['project_id']);;
	}
	else {
		$ret += ['xatolik'=>1,'xabar'=>'Empty project_id!!!'];
		exit();
	}

	if(!empty($_POST['object_name'])){
		$object_name = trim($_POST['object_name']);;
	}
	else {
		$ret += ['xatolik'=>1,'xabar'=>'Empty object_name!!!d'];
		exit();
	}

	if(!empty($_POST['floors'])){
		$floors = trim($_POST['floors']);;
	}
	else {
		$ret += ['xatolik'=>1,'xabar'=>'Empty floors!!!d'];
		exit();
	}

	if(!empty($_POST['rooms'])){
		$rooms = trim($_POST['rooms']);;
	}
	else {
		$ret += ['xatolik'=>1,'xabar'=>'Empty rooms!!!d'];
		exit();
	}

	if(!empty($_POST['surface'])){
		$surface = trim($_POST['surface']);;
	}
	else {
		$ret += ['xatolik'=>1,'xabar'=>'Empty surface!!!d'];
		exit();
	}

	if(!empty($_POST['section'])){
	  $section = trim($_POST['section']);;
	}
	else {
		$ret += ['xatolik'=>1,'xabar'=>'Empty section!!!'];
		exit();
	}

	$id = $_SESSION['pr_id'];
	$time = time();

	$sql = mysqli_query($link,"UPDATE objects SET 
	project_id = '$project_id',obj_name ='$object_name',floors ='$floors',rooms ='$rooms',surface = '$surface',section ='$section',updated_date ='$time'
    WHERE id = '$id'");

	if($sql){
		$ret += ['xatolik'=>0,'xabar'=>'done'];
		// echo trim("done");
	}
	else {
		echo "Something went wrong!!!";
	}

	echo json_encode($ret);
?>