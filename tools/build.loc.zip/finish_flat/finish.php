<?php 
	include '../config.php';

	
?>