<?php 
	session_start();
	include '../config.php';

	$ret = [];

	$id = $_POST['id'];

	$object_id = $_POST['object_id'];

	$section = trim($_POST['section']);

	$floor = trim($_POST['floor']);

	$flat = trim($_POST['flat']);

	$surface = trim($_POST['surface']);

	$workers = trim($_POST['workers']);

	if($_POST['status'] == "true"){
		$status = "Finished";
	}
	else {
		$status = "In proccess";
	}

	$id = $_SESSION['sec_id'];
	$time = time();

	$sql = mysqli_query($link,"UPDATE extra_object SET object_id  = '$object_id',floor = '$floor',flat = '$flat',
	 section = '$section',surface = '$surface',workers = '$workers',updated_date = '$time',status = '$status'
    WHERE id = '$id'");

	if($sql){
		$ret += ['xatolik'=> 0,'xabar'=>'Worker updated successfully!!!'];
	}
	else {
		$ret += ['xatolik'=> 1,'xabar'=>'Something went wrong!!!'];
	}

	echo json_encode($ret);
?>