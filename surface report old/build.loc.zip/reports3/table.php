<?php
session_start();
include "../config.php";

$id = $_POST["id"];

$sql = mysqli_query(
    $link,
    "SELECT object_id, section, IF(status='Finished', 'Finished', 'In proccess'), created_date, updated_date, COUNT(section), SUM(surface) FROM extra_object WHERE object_id='$id' GROUP BY section HAVING COUNT(section) > 0;"
);

// $sql3 = mysqli_query(
//     $link,
//     "SELECT status,section,surface, COUNT(*) FROM extra_object GROUP BY status,section
//      HAVING COUNT(*) > 1"
// );
// $arr = [];
// $sum = 0;
// while ($res3 = mysqli_fetch_assoc($sql3)) {
//    $new = array_push($arr,$res3['surface']);
//    echo array_sum($new);
// }

// exit();



$res = array();
$res2 = array();
$sum = 0;
// while($row2 = mysqli_fetch_assoc($sql2)){
//    if(($row2['section'] === $row2['section'])){
//        $sum += $row2['surface'];

//        array_push($res2,$row2['section']);
//    }
   
// }


while ($row = mysqli_fetch_assoc($sql)) {

   $section = $row['section'];
   $status = $row['status'];


    $id = $row['object_id'];
    $sql2 = mysqli_query($link,"SELECT * FROM objects WHERE id = '$id'");
    $res2 = mysqli_fetch_assoc($sql2);

    $sql3 = mysqli_query($link,"SELECT * FROM extra_object WHERE section = '$section' AND status='Finished'");
    $res3 = mysqli_fetch_assoc($sql3);

    if($row['updated_date'] == ""){
       $up = 0;
    }
    else{
       $up = date("Y-m-d",$row['updated_date']);

    }

    $cr = date("Y-m-d",$row['created_date']);

    array_push(
      $res, 
      [ 

         $res2["obj_name"],
         $row["section"],
         $row['SUM(surface)'],
         $cr,
         $up,
         $res3 ? "Finished" : "In proccess",
      ]
);
}



echo json_encode($res);
?>
   
