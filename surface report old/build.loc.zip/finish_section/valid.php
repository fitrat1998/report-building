<?php 
	include '../config.php';


	 $ret = [];

     if ($_POST['object_id'] == "Choose object") {
	 	$ret += ['xatolik'=>1,'xabar'=>'Choose object please!!!'];
	 }
	 else{
	 	 $id = trim($_POST['object_id']);
	 }


	 if ($_POST['section'] != "Choose section") {
	 	$section = trim($_POST['section']);
	 }
	 else{
	 	$ret += ['xatolik'=>1,'xabar'=>'Choose section please!!!'];
	 }

	 $surface = trim($_POST['surface']);

	 $workers = $_POST['worker'];

	 if($_POST['status'] == "true") {
	 	
	 	$status = "Finished";
	 }
	 else {
	 	$status = "In proccess";
	 }
	

	 $time = time();

	 $master = "";

	foreach($workers as $worker){
		$master .= $worker.", ";
	}

	$old = mysqli_query($link,"SELECT * FROM extra_object WHERE object_id = '$id' AND section = '$section' ORDER BY created_date DESC");
	$res = mysqli_fetch_assoc($old);

	$old2 = mysqli_query($link,"SELECT * FROM extra_object WHERE object_id = '$id' AND section = '$section' 
		AND status = 'In proccess' ORDER BY created_date DESC");

	
	$res2 = [];
	while ($row = mysqli_fetch_assoc($old2)) {
			$res2 [] = $row;
		}

	
	foreach ($res2 as $value) {
		// echo $value['status'];
		// print_r($value);
   }

	if($res['status'] == "Finished"){
		$ret += ['xatolik'=>1,'xabar'=>'The object already exists on the table!!!'];
		echo json_encode($ret);
		die();
	}
	else{
		$sql = mysqli_query($link,"INSERT INTO extra_object(object_id,floor,flat,section,surface,workers,created_date,updated_date,status)
	 	   VALUES('$id','','','$section','$surface','$master','$time','','$status')");

		 if($sql){
		 	$ret += ['xatolik'=>0, 'xabar'=>'Section added successfully!!!'];
		 }
		 else {
		 	$ret += ['xatolik'=>1,'xabar'=>'Something went wrong!!!'];
		 }

		 if ($status == "Finished") {
		 	 $update = mysqli_query($link,"UPDATE extra_object SET status = '$status' WHERE object_id = '$id' AND 
		 	 	section = '$section' AND status = 'In proccess'");
		 }
	}

	

	echo json_encode($ret);
?>