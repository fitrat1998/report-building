<?php 

date_default_timezone_set('Asia/Tashkent');

$script_tz = date_default_timezone_get();

if (strcmp($script_tz, ini_get('date.timezone'))){
    // echo 'Script timezone differs from ini-set timezone.';
} else {
    // echo 'Script timezone and ini-set timezone match.';
}

 ?>